import React from 'react';
import { RouterProvider } from 'react-router';
import { router } from '../router';
import { AuthProvider } from './contexts/AuthContext';

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  );
}